# Plano de Integração de Código GPS

Este plano detalha a integração do código de GPS e Mapa fornecido pelo usuário, adaptando-o para a arquitetura de Fragments existente sem quebrar a funcionalidade de navegação.

## User Review Required

> [!IMPORTANT]
> O código fornecido foi adaptado de uma `MainActivity` para o `VideosGpsFragment`. Isso é necessário porque o seu aplicativo utiliza um sistema de abas e Fragments. Colocar o código diretamente na `MainActivity` quebraria a navegação atual.

## Proposed Changes

### UI (Layout)

#### [MODIFY] [videos_gps.xml](file:///Users/senai/Downloads/youtube_gabi-main/app/src/main/res/layout/videos_gps.xml)
*   Alterar o ID do `TextView` de `tv_location_status` para `textGps` para coincidir com o código fornecido.
*   Garantir que a estrutura do botão e WebView siga as restrições (`Constraints`) fornecidas no snippet.
*   Manter a lista de vídeos e o título da página para não "quebrar" o design já existente.

### Lógica (Java)

#### [MODIFY] [VideosGpsFragment.java](file:///Users/senai/Downloads/youtube_gabi-main/app/src/main/java/com/example/youtube_gabi/VideosGpsFragment.java)
*   Atualizar as referências de variáveis para corresponder ao snippet (`textGps`).
*   Adicionar o `WebChromeClient` com log "MapaJS" conforme solicitado.
*   Garantir que as configurações de `WebSettings` (JavaScript e DomStorage) sejam aplicadas.
*   Implementar o `LocationCallback` e o `solicitarAtualizacaoLocalizacao` exatamente como no exemplo fornecido.

## Verification Plan

### Automated Tests
* Executar `./gradlew assembleDebug` para verificar erros de compilação.

### Manual Verification
1. Abrir o aplicativo e navegar até a aba "Local".
2. Clicar no botão "Pegar localização".
3. Verificar se as coordenadas aparecem no texto `textGps`.
4. Verificar se o mapa atualiza a posição (requer chave de API válida no `mapa.html`).
