# Tarefas: Integração do Código GPS do Usuário

- `[ ]` Atualizar Layout `videos_gps.xml`
    - `[ ]` Renomear `tv_location_status` para `textGps`
    - `[ ]` Ajustar constraints para bater com o snippet
- `[ ]` Atualizar Fragment `VideosGpsFragment.java`
    - `[ ]` Adaptar lógica da `MainActivity` fornecida para o Fragment
    - `[ ]` Implementar logs de console "MapaJS" no WebView
    - `[ ]` Configurar `LocationRequest` com `Priority.PRIORITY_HIGH_ACCURACY`
- `[ ]` Verificação
    - `[ ]` Build com sucesso
    - `[ ]` Validar funcionamento do botão e textos
