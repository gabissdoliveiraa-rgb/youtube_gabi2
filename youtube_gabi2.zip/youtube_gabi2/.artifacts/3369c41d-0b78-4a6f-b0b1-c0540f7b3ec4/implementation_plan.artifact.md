# Plan to Move Navigation Bar to Individual Screens

This plan describes moving the `BottomNavigationView` from the `MainActivity` host layout into each individual screen layout (`home.xml`, `sala.xml`, `perfil.xml`).

## User Review Required

> [!WARNING]
> Moving the navbar to individual fragments means the navigation logic must be duplicated or handled via a shared method. Also, the navbar will now animate along with the screen content during transitions, which may feel different from the standard persistent persistent navbar.

## Proposed Changes

### Layouts

#### [MODIFY] [activity_main.xml](file:///Users/senai/StudioProjects/youtube_gabi/app/src/main/res/layout/activity_main.xml)
- Remove the `BottomNavigationView`.
- Keep only the `FragmentContainerView`.

#### [MODIFY] [home.xml](file:///Users/senai/StudioProjects/youtube_gabi/app/src/main/res/layout/home.xml)
- Add the `BottomNavigationView` at the bottom of the `ConstraintLayout`.
- Adjust the main content scroll view to be above the navbar.

#### [MODIFY] [sala.xml](file:///Users/senai/StudioProjects/youtube_gabi/app/src/main/res/layout/sala.xml)
- Add the `BottomNavigationView` at the bottom.
- Adjust layout constraints to ensure content is visible.

#### [MODIFY] [perfil.xml](file:///Users/senai/StudioProjects/youtube_gabi/app/src/main/res/layout/perfil.xml)
- Add the `BottomNavigationView` at the bottom.
- Adjust layout constraints.

### Code

#### [MODIFY] [MainActivity.java](file:///Users/senai/StudioProjects/youtube_gabi/app/src/main/java/com/example/youtube_gabi/MainActivity.java)
- Remove the navigation listener.
- Add a public method to switch fragments that can be called from within fragments.

#### [MODIFY] [DiscoverFragment.java](file:///Users/senai/StudioProjects/youtube_gabi/app/src/main/java/com/example/youtube_gabi/DiscoverFragment.java)
#### [MODIFY] [VideoRoomFragment.java](file:///Users/senai/StudioProjects/youtube_gabi/app/src/main/java/com/example/youtube_gabi/VideoRoomFragment.java)
#### [MODIFY] [YourSpaceFragment.java](file:///Users/senai/StudioProjects/youtube_gabi/app/src/main/java/com/example/youtube_gabi/YourSpaceFragment.java)
- Initialize the `BottomNavigationView` in `onViewCreated`.
- Set the correct item as selected.
- Handle item selection by calling the fragment switch method in `MainActivity`.

## Verification Plan

### Manual Verification
- Deploy to emulator.
- Verify that each screen has the navbar.
- Verify that clicking an item in the navbar correctly navigates to the target screen.
- Ensure the correct item is highlighted on each screen.
