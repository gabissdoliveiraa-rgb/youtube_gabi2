package com.example.youtube_gabi;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import android.webkit.ConsoleMessage;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import java.util.Map;

public class VideosGpsFragment extends Fragment {

    private TextView textGps;
    private WebView webViewMapa;
    private FusedLocationProviderClient fusedLocationClient;
    private ActivityResultLauncher<String[]> localizacaoLauncher;
    private LocationCallback locationCallback;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        localizacaoLauncher = registerForActivityResult(
            new ActivityResultContracts.RequestMultiplePermissions(),
            (Map<String, Boolean> resultado) -> {
                Boolean fineConcedida = resultado.get(Manifest.permission.ACCESS_FINE_LOCATION);
                Boolean coarseConcedida = resultado.get(Manifest.permission.ACCESS_COARSE_LOCATION);
                if (Boolean.TRUE.equals(fineConcedida) || Boolean.TRUE.equals(coarseConcedida)) {
                    solicitarAtualizacaoLocalizacao();
                } else {
                    if (textGps != null) {
                        textGps.setText("Permissão de localização negada");
                    }
                }
            }
        );
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.videos_gps, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        textGps = view.findViewById(R.id.textGps);
        webViewMapa = view.findViewById(R.id.webViewMapa);
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity());

        WebSettings webSettings = webViewMapa.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);

        webViewMapa.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                Log.d("MapaJS", consoleMessage.message() + " -- linha " + consoleMessage.lineNumber());
                return true;
            }
        });
        webViewMapa.loadUrl("file:///android_asset/mapa.html");

        locationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                for (android.location.Location location : locationResult.getLocations()) {
                    double lat = location.getLatitude();
                    double lng = location.getLongitude();

                    textGps.setText("Lat: " + lat + " | Long: " + lng);
                    webViewMapa.evaluateJavascript("updateLocation(" + lat + ", " + lng + ")", null);
                }
                fusedLocationClient.removeLocationUpdates(locationCallback);
            }
        };

        Button botaoLocalizacao = view.findViewById(R.id.btnPegarLocalizacao);
        if (botaoLocalizacao != null) {
            botaoLocalizacao.setOnClickListener(v -> {
                if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    solicitarAtualizacaoLocalizacao();
                } else {
                    localizacaoLauncher.launch(new String[]{
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    });
                }
            });
        }
    }

    private void solicitarAtualizacaoLocalizacao() {
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        textGps.setText("Buscando localização...");
        LocationRequest locationRequest = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 2000)
            .setMaxUpdates(1)
            .build();
            
        fusedLocationClient.requestLocationUpdates(
            locationRequest,
            locationCallback,
            Looper.getMainLooper()
        );
    }
}