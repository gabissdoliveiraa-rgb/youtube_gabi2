package com.example.youtube_gabi;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class YourSpaceFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.perfil, container, false);

        View tabConteudo = view.findViewById(R.id.tab_conteudo);
        if (tabConteudo != null) {
            tabConteudo.setOnClickListener(v -> {
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new ProfileContentFragment())
                        .commit();
            });
        }

        View imgProfileTop = view.findViewById(R.id.img_profile_top);
        if (imgProfileTop != null) {
            imgProfileTop.setOnClickListener(v -> {
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragment_container, new SettingsFragment())
                        .commit();
            });
        }

        return view;
    }
}
